#!/usr/bin/perl
my $usage=<<USAGE;
Usage:
     perl  $0   RFGB_genotype..geno
     The 3000 rice geno data file can be downloaded from: http://www.rmbreeding.cn/Genotype/haplotype

e.g. perl  RFGB_3000rice_genotype2vcf.pl  LOC_Os08g12780.genomic.geno
     gffread  all.gff3   -T -o Os.gtf
     gtfToGenePred -genePredExt Os.gtf  os_refGene.txt
     retrieve_seq_from_fasta.pl --format refGene --seqfile  all.chrs.con  os_refGene.txt --outfile os_refGeneMrna.fa
     table_annovar.pl  LOC_Os08g12780.genomic.vcf  ./  --vcfinput --outfile  Rice3000 --buildver  os --protocol refGene --operation g -remove
     perl  vcf2hmp.pl  LOC_Os08g12780.genomic.vcf   Rice3000.os_multianno.txt  0.1
     perl  CandiHap.pl  ./haplotypes.hmp  ./thousand_grain_weight.txt  ./all.gff3  LOC_Os08g12780
USAGE

print $usage if(@ARGV==0);
exit if(@ARGV==0);

$ARGV[0] =~ /(\S+)\.geno/;
$out = $1;
print "$out\n";
system("rm -rf $out.vcf");

open OUT,">>$out.vcf" or die $!;
open VCF, "$ARGV[0]" or die $!;
while (<VCF>) {
    $_ =~ s/\r*\n*//g;
    if ($_ =~ /^Chr\tPos/) {
        @names = split(/\t/,$_);
        print OUT  "#CHROM	POS	ID	REF	ALT	QUAL	FILTER	INFO	FORMAT	" . join ("\t",@names[7..$#names]) . "\n";
    }
    last;
}
close VCF;

while(<ANNOVAR>){
    next if $_ =~ /^Chr\tPos/;
    $_ =~ s/\r*\n*//g;
    @a = split(/\t/,$_);
    #next if $a[5] =~ /intergenic/;
    $chrpos = "$a[0]:$a[1]";
    for ($i = 7; $i <= $#a; $i++){
        if ($a[$i] eq '-') {
            $a[$i] = 'N/N' ;
        }
        elsif ($a[$i] =~ /(.*)/ ) {
            $Fir = $1;
            @alt = split(/,/,$a[3]);
            unshift( @alt, $a[2]);
            $a[$i] = '0/0' if $Fir eq $alt[0];
            $a[$i] = '1/1' if $Fir eq $alt[1];
            $a[$i] = '2/2' if $Fir eq $alt[2];
            $a[$i] = '0/1' if $Fir =~ /[RSWKYM]/;
           # $a[$i] = $alt[$Fir].'/'.$alt[$Sen];
        }
    }
    $a[5] = 'AC=60;AF=' . $a[5] . ';AN';
    print OUT "$a[0]\t$a[1]\t$chrpos\t$a[2]\t$a[3]\t30000\tPASS\t$a[5]\tGT\t". join ("\t",@a[7..$#a]) . "\n";
}
close ANNOVAR;

open ANNOVAR,$ARGV[0] or die $!;
while(<ANNOVAR>){
    next if $_ =~ /^Chr\tPos/;
    $_ =~ s/\r*\n*//g;
    @a = split(/\t/,$_);
    #next if $a[5] =~ /intergenic/;
    $chrpos = "$a[0]:$a[1]";
    for ($i = 7; $i <= $#a; $i++){
        if ($a[$i] eq '-') {
            $a[$i] = 'N/N' ;
        }
        elsif ($a[$i] =~ /(.*)/ ) {
            $Fir = $1;
            @alt = split(/,/,$a[3]);
            unshift( @alt, $a[2]);
            $a[$i] = '0/0' if $Fir eq $alt[0];
            $a[$i] = '1/1' if $Fir eq $alt[1];
            $a[$i] = '2/2' if $Fir eq $alt[2];
            $a[$i] = '0/1' if $Fir =~ /[RSWKYM]/;
           # $a[$i] = $alt[$Fir].'/'.$alt[$Sen];
        }
    }
    $a[5] = 'AC=60;AF=' . $a[5] . ';AN';
    print OUT "$a[0]\t$a[1]\t$chrpos\t$a[2]\t$a[3]\t30000\tPASS\t$a[5]\tGT\t". join ("\t",@a[7..$#a]) . "\n";
}
close ANNOVAR;