#!/usr/bin/perl
use POSIX qw(strftime);
use Getopt::Std;
use File::Basename;
use threads;
sub usage {
    die(
        qq!
CandiHap: An R Platform for haplotype analysis on variation study

Usage:    perl  $0  -m Your.hmp  -f Genome.gff  -p Phenotype.txt  -g Your_gene_ID
  e.g.    perl  CandiHap.pl  -m haplotypes.hmp  -f test.gff  -p Phenotype.txt  -g Si9g49990
  e.g.    perl  CandiHap.pl  -m haplotypes.hmp  -f test.gff  -p Phenotype.txt  -g Si9g49990 -s 0.5 -u 2000 -d 500 -l 1 -n Structure.txt
  e.g.    perl  CandiHap.pl  -m haplotypes.hmp  -f Si.Ann_RNA.gff  -p Phenotype.txt  -g Si9g18150 -s 1 -u 2000 -d 500 -l 1 -n Structure.txt -k

Command:  -m    input hmp file name (Must)
          -p    input phenotype file name (Must)
          -f    input gff file name (Must)
          -g    Your gene ID (Must)
          -s    p value of wilcox test. default is 1.
          -u    gene upstream. default is 2000 bp.
          -d    gene downstream. default is 500 bp.
          -l    Plot LDheatmap (1) or not (0). default is not 0. require R package "LDheatmap" and "genetics".
          -n    input pop file name and plot haploNet figure. default is NULL. require R package "pegas".
          -k    keek all tmp files
          -h    this (help) message

Author:   Xukai Li, xukai_li\@sxau.edu.cn
Version:  V1.3.0
Update:   2022/12/01
Notes:    CandiHap: a haplotype analysis toolkit for natural variation study.
          bioRxiv, 2020.02.27.967539.
          doi: https://doi.org/10.1101/2020.02.27.967539
\n!
    )
}

my %opts;
getopts('m:p:f:g:n:s:u:d:l:kh', \%opts);
&usage unless ( exists $opts{m} && exists $opts{p} && exists $opts{f}  && exists $opts{g});
&usage if $opt{h};
my $start_time=time;
print strftime("Start time is %Y-%m-%d %H:%M:%S\n", localtime(time));
$opts{k}=0 unless defined($opts{k});
$opts{s}=1 unless defined($opts{s});
$opts{n}=0 unless defined($opts{n});
$opts{l}=0 unless defined($opts{l});
$opts{u}=2000 unless defined($opts{u});
$opts{d}=500 unless defined($opts{d});
print "Input files are:\n";
foreach my $key ( sort keys %opts){
    print $key, "--> ",$opts{$key},"\n";
}

basename($opts{p}) =~ /(\S+)\.txt/;
$Phenotype = $1;
$mychr = $mystart = $myend =0;
print "\n\nReading $opts{f} GFF file for gene $opts{g} ......\n";
system("grep  '$opts{g}' $opts{f} > tmp-gene_gff-$opts{g}-$Phenotype.txt");
open GFF ,"tmp-gene_gff-$opts{g}-$Phenotype.txt" or die "$!";
while (<GFF>) {
    $_ =~ s/\n*|\r*//g;
    if($_ =~ /\texon\t/){
        @F = split(/\t/,$_);
        $F[8]=~/Parent=(.*?);/;
        $cds_pos{$1}{"$F[3] $F[4] $F[7]"}=1;
        $contig{$1}=$F[0];
        $stream{$1}=$F[6];
    }
    if ($_ =~ /\tgene\t/){
        @gff = split(/\t/,$_);
        $mychr = $gff[0];
        if ($gff[6] eq '+') {
            $mystart = $gff[3] - $opts{u};
            $myend   = $gff[4] + $opts{d};
        }
        elsif ($gff[6] eq '-') {
            $mystart = $gff[3] - $opts{d};
            $myend   = $gff[4] + $opts{u};
        }
    }
}
close GFF;
$gene_n = `grep -E 'mRNA\t' tmp-gene_gff-$opts{g}-$Phenotype.txt |wc -l`;
$gene_n =~ s/\s+//g;
print "Read $opts{f} file done.\n\n\n";
print "Query:  $opts{g} $gene_n --> $mychr  $mystart  $myend\n\n";

print "Reading $opts{p} file for phenotype ......\n";
open PHENOTYPE ,"$opts{p}" or die "$!";
while(<PHENOTYPE>){
    $_ =~ s/\n*|\r*//g;
    @F = split(/\t/,$_);
    $name{$F[0]} = $F[1] if $_ ne 'NaN' or 'NA';
}
close PHENOTYPE;
print "Read $opts{p} file done.\n\n\n";

print "Reading $opts{m} file for gene $opts{g} ......\n";
#system("grep -E '$opts{g}|CHROM' $opts{m}$mychr > tmp-hmp-$opts{g}-$Phenotype.txt");
system("grep -E '$opts{g}|CHROM' $opts{m} > tmp-hmp-$opts{g}-$Phenotype.txt");

#http://bioinfor.imu.edu.cn/raacbook/public/
%Hydrophobicity = (
	'R' => 'polar', 'K' => 'polar', 'E' => 'polar', 'D' => 'polar', 'Q' => 'polar', 'N' => 'polar', 
	'G' => 'neutral', 'A' => 'neutral', 'S' => 'neutral', 'T' => 'neutral', 'P' => 'neutral', 'H' => 'neutral', 'Y' => 'neutral', 
	'C' => 'hydropho_bicity', 'L' => 'hydropho_bicity', 'V' => 'hydropho_bicity', 'I' => 'hydropho_bicity', 'M', => 'hydropho_bicity', 'F' => 'hydropho_bicity', 'W' => 'hydropho_bicity'
);
%Polarity = (
	'L' => '4.9~6.2', 'I' => '4.9~6.2', 'F' => '4.9~6.2', 'W' => '4.9~6.2', 'C' => '4.9~6.2', 'M' => '4.9~6.2', 'V' => '4.9~6.2', 'Y' => '4.9~6.2', 
	'P' => '8.0~9.2', 'A' => '8.0~9.2', 'T' => '8.0~9.2', 'G' => '8.0~9.2', 'S' => '8.0~9.2', 
	'H' => '10.4~13.0', 'Q' => '10.4~13.0', 'R' => '10.4~13.0', 'K' => '10.4~13.0', 'N', => '10.4~13.0', 'E' => '10.4~13.0', 'D' => '10.4~13.0'
);
%Charge = (
	'K' => 'positive', 'R' => 'positive', 
	'A' => 'neutral', 'N' => 'neutral', 'C' => 'neutral', 'Q' => 'neutral', 'G' => 'neutral', 'H' => 'neutral', 'I' => 'neutral', 'L' => 'neutral', 'M' => 'neutral', 'F' => 'neutral', 'P' => 'neutral', 'S' => 'neutral', 'T' => 'neutral', 'W' => 'neutral', 'Y' => 'neutral', 'V' => 'neutral', 
	'D' => 'negative', 'E' => 'negative'
);
%Secondary_structure = (
	'E' => 'helix', 'A' => 'helix', 'L' => 'helix', 'M' => 'helix', 'Q' => 'helix', 'K' => 'helix', 'R' => 'helix', 'H' => 'helix', 
	'V' => 'strand', 'I' => 'strand', 'Y' => 'strand', 'C' => 'strand', 'W' => 'strand', 'F' => 'strand', 'T' => 'strand', 
	'G' => 'coil', 'N' => 'coil', 'P' => 'coil', 'S' => 'coil', 'D', => 'coil'
);

open HMP, "tmp-hmp-$opts{g}-$Phenotype.txt" or die $!;
while (<HMP>) {
    $_ =~ s/\r*\n*//g;
    if ($_ =~ /CHROM/) {
        @names = split(/\t/,$_);
        $n  = "$names[1]\t$names[2]\t$names[3]\t$names[4]\t$names[5]\t" . join ("\t",@names[6..$#names]);
    }
    next if $_ !~ /^$mychr\t/;
    #next if ($_ =~ /:: synonymous/);
    @a = split(/\t/,$_);
    next if ($a[1] < $mystart or $a[1] > $myend);
    $BP{$a[1]} = $a[2] . '->'. $a[3];
    $INFO{$a[1]} = $a[4];
    #$a[4] =~ /EFF=(.*)/;
    if ($a[4] =~ /nonsynonymous|stop/) {
        $a[4] =~ /:p\.(\w)\d+(\w)/;
        #print "$a[0]:$a[1]\n$a[4]\nHydrophobicity: $Hydrophobicity{$1}-$Hydrophobicity{$2}\nPolarity: $Polarity{$1}-$Polarity{$2}\nCharge: $Charge{$1}-$Charge{$2}\nSecondary_structure: $Secondary_structure{$1}-$Secondary_structure{$2}\n\n";
        $a[4] = $a[4] . "; Hydrophobicity: $Hydrophobicity{$1}-$Hydrophobicity{$2}, Polarity: $Polarity{$1}-$Polarity{$2}, Charge: $Charge{$1}-$Charge{$2}, Secondary_structure: $Secondary_structure{$1}-$Secondary_structure{$2}" if ($1 ne $2);
    }
    for ($i = 6; $i <= $#a; $i++){
        if (($name{$names[$i]} > 0 or $name{$names[$i]} eq '0') and ($a[$i] !~ /N/)) {
            $a[$i] =~ /(.*)\/(.*)/;
            next if ($1 ne $2);
            next if ($a[$i] !~ /[ATCG+-]/);
            $TT = "$a[1]\t$a[$i]";
            $Ttest{$TT} .= "$TT\t$name{$names[$i]}\t$names[$i]\n";
        }
    }
    $l = "$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t" . join ("\t",@a[6..$#a]);
    push @lxk , $l;
}
push @lxk , $n;
print "Read $opts{m} file done.\n\n\n";

open OUT,">tmp-wilcox-$opts{g}-$Phenotype.txt" or die $!;
foreach  $k (sort {$a<=>$b} keys %Ttest ){
    print OUT "$Ttest{$k}";
}

open OUTR,">wilcox-$opts{g}-$Phenotype.R" or die $!;
print OUTR <<EOF;
data <- read.table("tmp-wilcox-$opts{g}-$Phenotype.txt", header=F,sep="\\t")
for (i in unique(data\$V1)) {
    test =''
    pvalue =1
    merge=''
    mydata=data[which(data\$V1 == i), ]
    if (length(unique(mydata\$V2)) ==1)
    merge = cbind(i,pvalue)
    if (length(unique(mydata\$V2)) ==1)
    write.table(merge, file = "tmp-wilcox_result-$opts{g}-$Phenotype.txt", sep = "\\t", quote = FALSE, col.names = FALSE, row.names = FALSE, append = T)
    if (length(unique(mydata\$V2)) ==1)
    next
    test <- wilcox.test(V3 ~ V2, data = mydata)
    pvalue <- test\$p.value
    #fdr=p.adjust(pvalue, method="fdr", n=nrow(mydata))
    merge = cbind(i,pvalue)
    write.table(merge, file = "tmp-wilcox_result-$opts{g}-$Phenotype.txt", sep = "\\t", quote = FALSE, col.names = FALSE, row.names = FALSE, append = T)
}
EOF
system("Rscript wilcox-$opts{g}-$Phenotype.R");

@a ='';
open TEST, "tmp-wilcox_result-$opts{g}-$Phenotype.txt" or die $!;
while (<TEST>) {
    $_ =~ s/\r*\n*//g;
    @a = split(/\t/,$_);
    $wilcox{$a[0]} = $a[1];
    push (@b , $a[1]) if ($a[1] > 0);
}
@b = grep(/[\d]/, @b);
@b=sort {$a<=>$b}@b;
$wilcox_max = $b[$#b];
$wilcox_min = $b[0];
$wilcox_min = 0.01  if ($wilcox_min > 0.01);
@b='';

#$threshold = 10 ** (log($wilcox_min)/log(10) * 0.6);
$threshold = 1;
print "The minimum wilcox test is: $wilcox_min\nThe wilcox test threshold is: $threshold\n\n";

open OUT,">tmp-$opts{g}-$Phenotype.txt" or die $!;
for (@lxk) {
    my @a = split /\t/, $_;
    for (my $i=0;$i<@a;$i++){
        $out{$i}{$a[0]} = $a[$i];
    }
}
foreach my $k (sort {$a<=>$b} keys %out ){
    my $out;
    foreach $d (sort {$a<=>$b} keys %{$out{$k}}){
        $out .= "$out{$k}{$d}\t"  if ($wilcox{$d} <= $opts{s});
    }
    $out =~ s/\t$//g;
    print OUT "$out\n";
}
close IN;
close OUT;

if ($opts{l}) {
open OUTR,">LDheatmap-$opts{g}-$Phenotype.R" or die $!;
print OUTR <<EOF;
if (! require("BiocManager", quietly = TRUE)) install.packages("BiocManager", repos='https://cran.rstudio.com/')
if (! require("LDheatmap")) BiocManager::install("LDheatmap")
if (! require("genetics")) install.packages("genetics", repos='https://cran.rstudio.com/')
data <- read.table("tmp-$opts{g}-$Phenotype.txt", header=F,sep="\\t",row.names=1)
NAs <- data == "N/N"
is.na(data)[NAs] <- TRUE
data[NAs] <- NA
Dist = as.numeric(data[1,])
mydata = data[-1,]
mydata = mydata[-1,]
mydata = mydata[-1,]
mydata = mydata[-1,]
snp = mydata[-1,]
num<-ncol(snp) 
 for(i in 1:num){
   snp[,i]<-as.genotype(snp[,i]) 
 }
pdf(file="Plot-LDheatmap-$opts{g}.pdf", width=6, height=4)
rgb.palette <- colorRampPalette(rev(c("#1F77B4", "#AEC7E8", "#FF7F0E")), space = "rgb")
LDheatmap(snp, genetic.distances = Dist, flip = TRUE, color=rgb.palette(40))
dev.off()
EOF
system("Rscript LDheatmap-$opts{g}-$Phenotype.R");
print "Plotted Gene LDheatmap to file Plot-LDheatmap-$opts{g}.pd\n\n";
}

@a ='';
open TEST, "tmp-wilcox_result-$opts{g}-$Phenotype.txt" or die $!;
while (<TEST>) {
    $_ =~ s/\r*\n*//g;
    @a = split(/\t/,$_);
    $wilcox{$a[0]} = $a[1];
    push (@b , $a[1]) if $a[1] > 0;
}
@b = grep(/[\d]/, @b);
@b=sort {$a<=>$b}@b;
$wilcox_max = $b[$#b];
$wilcox_min = $b[0];
@b='';

@a ='';
open FILE, "tmp-$opts{g}-$Phenotype.txt" or die $!;
while (<FILE>) {
    if ($_ =~ /^POS/ ) {
        $_ =~ s/\r*\n*//g;
        @a = split(/\t/,$_);
        $POS = "SNP positions\t". join ("\t",@a[1..$#a]) . "\tNumber of varieties\tVarieties ID\tAverage\tStdev\tSignificant Difference";
        $test = "Wilcox test\t";
       # $test2 = "Normalization\t";
        #$score = "Score\t";
        for (1..$#a) {
            $test .= "$wilcox{$a[$_]}\t"  if ($wilcox{$d} <= $opts{s});
            #$normalization = ($wilcox{$a[$_]} - $wilcox_min) / ($wilcox_max - $wilcox_min);
            #$test2 .= "$normalization\t";
            #$S = (1- ($wilcox{$a[$_]} / $wilcox_max))*100;
            #$S = (1- ($wilcox{$a[$_]} - $wilcox_min) / ($wilcox_max - $wilcox_min))*100;
            #$score .= "$S\t";
        }
        next;
    }

    if ($_ =~ /^REF/  ) {
        $_ =~ s/\r*\n*//g;
        @a = split(/\t/,$_);
        $ref = "References allele\t". join ("\t",@a[1..$#a]);
        next;
    }
   if ($_ =~ /^ALT/ ) {
        $_ =~ s/\r*\n*//g;
        @a = split(/\t/,$_);
        $alt = "Alternative allele\t". join ("\t",@a[1..$#a]);
        next;
    }
    if ($_ =~ /^INFO/ ) {
        $_ =~ s/\r*\n*//g;
        $stop = $1 if $_ =~ /(stop\w+)/;
        @a = split(/\t/,$_);
        $EFF = "SNP annotation\t". join ("\t",@a[1..$#a]);
        next;
    }
    if ($_ =~ /^Allele/ ) {
        $_ =~ s/\r*\n*//g;
        @a = split(/\t/,$_);
        $All = "Allele Frequency\t". join ("\t",@a[1..$#a]);
        next;
    }
    $_ =~ s/\r*\n*//g;
    @a = split(/\t/,$_);
    $n = join ("\t",@a[1..$#a]);
    $lxk{$n} .= "$a[0] : $name{$a[0]}, ";
    $Line{$a[0]} = "$n!!\t$a[0]\t$name{$a[0]}";
    $ave{$n} .= "$name{$a[0]} " if $name{$a[0]} =~ /\d/;
    $lxk2{$n} ++;
}
open HMP, "tmp-hmp-$opts{g}-$Phenotype.txt" or die $!;
while (<HMP>) {
    $_ =~ s/\r*\n*//g;
    if ($_ =~ /CHROM/) {
        @names = split(/\t/,$_);
        $n  = "$names[1]\t$names[2]\t$names[3]\t$names[4]\t$names[5]\t" . join ("\t",@names[6..$#names]);
    }
    next if $_ !~ /^$mychr\t/;
    @a = split(/\t/,$_);
    next if ($a[1] < $mystart or $a[1] > $myend);
    for ($i = 6; $i <= $#a; $i++){
        if (length($a[2]) ==1  and length($a[3]) ==1 ) {
            $a[$i] =~ /(.)(.)(.)/;
            $seq{$names[$i]} .=  $1  if ($wilcox{$a[1]} <= $opts{s} and $opts{n} );
        }
    }
}

open BOX,">tmp-Boxplot-$Phenotype-$opts{g}.txt" or die $!;
open TMP,">tmp-Hap-$opts{g}-$Phenotype.txt" or die $!;
print TMP "$ref\n$alt\n$All\n$EFF\n$test\n$POS\n";
#print TMP "$ref\n$alt\n$All\n$EFF\n$test\n$test2\n$score\n$POS\n";
$i =1 ;
foreach my $k (sort {$lxk2{$b} <=> $lxk2{$a} } keys %lxk2 ){
    $hap = Hap_ . $i;
    $lxk{$k} =~ s/, $//g;
    @ave2 = split(/ /,$ave{$k});
    if (@ave2 > 1) {
        $ave{$k} = &average(\@ave2);
        $std{$k} = &stdev(\@ave2);
    }
    if (@ave2 > 2) {
        for (@ave2) {
            print BOX "$hap\t$_\n";
        }
    }
    if (@ave2 < 2) {
        for (@ave2) {
            $lxk{$k} =~ /(.*) :/;
            $seqX{$1} = $1;
        }
    }
    $Line2{$k} = $hap;
    print TMP "$hap\t$k\t$lxk2{$k}\t$lxk{$k}\t$ave{$k}\t$std{$k}\t$diff{$hap}\n";
    $i ++;
}
if ($opts{n}) {
    open STRUCTURE, "$opts{n}" or die $!;
    while (<STRUCTURE>) {
        $_ =~ s/\r*\n*//g;
        @a = split(/\t/,$_);
        $structure{$a[0]} = $a[1];
    }
    open SEQ, ">tmp-seq-$opts{g}.txt" or die $!;
    foreach my $k (sort {$a<=>$b} keys %seq ){
        next if $seq{$k} =~ /N/;
        next if exists $seqX{$k};
        print SEQ ">$structure{$k}\n$seq{$k}\n" if exists $structure{$k};
    }
}
open LINE,">Line_hap-$opts{g}-$Phenotype.txt" or die $!;
$POS =~ s/Average\tStdev\tSignificant Difference//g;
$POS =~ s/ /_/g;
print LINE "$POS\n";
foreach my $k (sort keys %Line ) {
    @a = split(/!!/,$Line{$k});
    $Line{$k} =~ s/!!//g;
    print LINE "$Line2{$a[0]}\t$Line{$k}\n";
}

for ($i =1; $i <= $gene_n; $i++) {
  $new_gff = $opts{g} . '.' . $i;
  system("grep  '$new_gff;' tmp-gene_gff-$opts{g}-$Phenotype.txt > tmp-gene_gff-$new_gff-$Phenotype.txt");
}

foreach $k (keys %BP ){
    if ($wilcox{$k} > $opts{s}) {
        delete($BP{$k});
    }
}

sub average{
        my($data) = @_;
        if (not @$data) {
                die("Empty array\n");
        }
        my $total = 0;
        foreach (@$data) {
                $total += $_;
        }
        my $average = $total / @$data;
        return $average;
}
sub stdev{
        my($data) = @_;
        if(@$data == 1){
                return 0;
        }
        my $average = &average($data);
        my $sqtotal = 0;
        foreach(@$data) {
                $sqtotal += ($average-$_) ** 2;
        }
        my $std = ($sqtotal / (@$data-1)) ** 0.5;
        return $std;
}

foreach $k (sort {$a<=>$b} keys %BP ){
    $w++ if ($k < $old + 0.07* ($myend - $mystart));
    $w=1 if ($k > $old + 0.07* ($myend - $mystart));
    $d= $w * (-0.2);
    $old = $k;
    $ff = $d if ($d < $ff);
}
$pin = $ff - 0.1;
$pin = -9 if ($ff >= -8);
$d=0; $w =0; $old =0; $k=0, $ff=0;
$Hpin = abs($pin) * 7 / 9;
print "Plotting Gene Structure of $opts{g} ......\nAnd plotting Histogram of $Phenotype ......\n";
open OUTR,">Plot_gene-$opts{g}-$Phenotype.R" or die $!;
print OUTR <<EOF;
x = read.table("$opts{p}")
y = x\$V2
Pheno = y[2:length(y)]
Phenoty =  as.numeric(as.character(Pheno))
Phenotype = Phenoty[!is.nan(Phenoty)]
P=shapiro.test(Phenotype)\$p.value
h = hist(Phenotype)
m=max(h\$counts) * 1.2
pdf(file="Plot_hist-$Phenotype.pdf", width=10, height=5)
par(mfrow=c(1,2))
h = hist(Phenotype, col='gray' ,xlab='Phenotype' , main="Histogram of $Phenotype", labels = TRUE, ylim = c(0,m))
rug(jitter(Phenotype))
xfit<-seq(min(Phenotype), max(Phenotype), length=100)
yfit<-dnorm(xfit, mean=mean(Phenotype), sd=sd(Phenotype))
yfit<-yfit*diff(h\$mids[1:2]) * length(Phenotype)
lines(xfit, yfit, col='darkblue', lwd=1)
lines(density(Phenotype)\$x, density(Phenotype)\$y * max(h\$counts)/max(h\$density), col='red',lwd=1)
text(min(Phenotype),m, expression(paste(italic("P =  "))))
text(min(Phenotype),m, labels=round(P,3), pos=4)

d=max(h\$density) * 1.2
hist(Phenotype, freq=FALSE, col='gray', xlab='Phenotype', main="Histogram of $Phenotype", ylim = c(0,d))
rug(jitter(Phenotype))
lines(density(Phenotype),col='red',lwd=1)
curve(dnorm(x, mean=mean(Phenotype), sd=sd(Phenotype)), add=TRUE, col="darkblue", lwd=1)
text(min(Phenotype),d, expression(paste(italic("P =  "))))
text(min(Phenotype),d, labels=P, pos=4)
dev.off()

mutation_plot_rect<-function(start, stop, text="", drop=-0.15, col="red") {
   rect(start, -0.03, stop, drop, col=col, border=col)
}
mutation_plot_text<-function(start, stop, text="", drop=-0.15, col="red") {
   text(stop+180, drop-0.15, text, cex=0.5, col=col, pos=4, offset=-1)
}
genemodel_plot<-function(model, xaxis=TRUE, drop=0) {
  par(mar=c(1,1,3,1), cex=1)
  colnames(model) =c('chr','db','feature','start','end','tmp1','orientation','tmp3','gene')
  orientation = model\$orientation[1]
  start <- min(c(model\$start,model\$end))
  end <- max(c(model\$start,model\$end))
  tmp_min=min(c(model\$start,model\$end))
  model\$start=model\$start-tmp_min+1
  model\$end=model\$end-tmp_min+1
  tmp_max=max(c(model\$start,model\$end))
  tmp_min=min(c(model\$start,model\$end))
  model<-cbind(as.character(model[,3]), as.numeric(model[,4]), as.numeric(model[,5]) )
  model<-as.data.frame(model)
  colnames(model)<-c("feature", "start", "bpstop")
  model\$start<-as.numeric(as.character(model\$start));model\$bpstop<-as.numeric(as.character(model\$bpstop))
  length<-tmp_max-tmp_min
  if (orientation=="-") {
    model\$newstart<-start+model\$start-1
    model\$newstop<-start+model\$bpstop-1
    model<-model[which(model\$feature!="exon"),]
    model<-model[which(model\$feature!="gene"),]
    #plot(1, type="l",axes=F,ann=FALSE, xlim=c(start-2010, end+2500), ylim=c($pin, 0.4))
    plot(1, type="l",axes=F,ann=FALSE, xlim=c(start-$opts{d}-500, end+$opts{u}+1000), ylim=c($pin, 0.4))
    for (i in 1:nrow(model)) {
      type<-model\$feature[i]
      if (type=="CDS") {
        rect(model\$newstart[i], 0 - drop, model\$newstop[i], 0.2 - drop, col = "steelblue3", border="dodgerblue4", lwd=1)
      }
      if (type=="mRNA") {
        arrows(x0=model\$newstop[i]+$opts{u},y0=0.1 - drop,x1=model\$newstart[i]-$opts{d},y1=0.1 - drop, lwd=1, col="dodgerblue4", length = 0.1)
      }
      if (type=="three_prime_UTR") {
        rect(model\$newstart[i], 0 - drop, model\$newstop[i], 0.2 - drop, col = "lightsteelblue1", border="dodgerblue4", lwd=1)
      }
      if (type=="five_prime_UTR") {
        rect(model\$newstart[i], 0 - drop, model\$newstop[i], 0.2 - drop, col = "lightsteelblue1", border="dodgerblue4", lwd=1)
      }
    }
  }
  if (orientation=="+") {
    model\$newstart<-start+model\$start-1
    model\$newstop<-start+model\$bpstop-1
    model<-model[which(model\$feature!="exon"),]
    model<-model[which(model\$feature!="gene"),]
    #plot(1, type="l",axes=F,ann=FALSE, xlim=c(start-2500, end+2010), ylim=c($pin, 0.4))
    plot(1, type="l",axes=F,ann=FALSE, xlim=c(start-$opts{u}-500, end+$opts{d}+1000), ylim=c($pin, 0.4))
    for (i in 1:nrow(model)) {
      type<-model\$feature[i]
      if (type=="mRNA") {
        arrows(x0=model\$newstart[i]-$opts{u},y0=0.1 - drop,x1=model\$newstop[i]+$opts{d},y1=0.1 - drop, lwd=1, col="dodgerblue4", length = 0.1)
      }
      if (type=="CDS") {
        rect(model\$newstart[i], 0 - drop, model\$newstop[i], 0.2 - drop, col = "steelblue3", border="dodgerblue4", lwd=1)
      }
      if (type=="three_prime_UTR") {
         rect(model\$newstart[i], 0 - drop, model\$newstop[i], 0.2 - drop, col = "lightsteelblue1", border="dodgerblue4", lwd=1)
      }
      if (type=="five_prime_UTR") {
        rect(model\$newstart[i], 0 - drop, model\$newstop[i], 0.2 - drop, col = "lightsteelblue1", border="dodgerblue4", lwd=1)
      }
    }
  }
  if (xaxis==T)   {
    Axis(side=3, labels=T, cex.axis=0.7)
  }
}
pdf(file="Plot_gene-$opts{g}-$Phenotype.pdf", width=7, height=$Hpin)
EOF

for ($i = 1; $i <= $gene_n; $i++) {
  $new_gff = $opts{g} . '.' . $i;
  $new_gff = $opts{g} if (-z "tmp-gene_gff-$new_gff-$Phenotype.txt");
  #$j = ($i)*0.5;
  print OUTR "$new_gff <- read.table('tmp-gene_gff-$new_gff-$Phenotype.txt',stringsAsFactors = F, header = F,comment.char = \"#\",sep = '\\t')\n";
  print OUTR "genemodel_plot(model=$new_gff, xaxis=T, drop=0)\n";
  print OUTR "text($mystart + 1000, 0.5, \"$new_gff\", cex=0.7, col=\"black\", pos=4, offset=-1)\n";
  $w =1;$old=0;
  foreach $k (sort {$a<=>$b} keys %BP ){
    $w++ if ($k < $old + 0.07* ($myend - $mystart));
    $w=1 if ($k > $old + 0.07* ($myend - $mystart));
    $d= $w * (-0.2);
    #print OUTR "mutation_plot($k, $k, \"$BP{$k}\", $d, col=\"black\")\n";
    print OUTR "mutation_plot_rect($k, $k, \">$k\", $d, col=\"#949494\")\n" if $INFO{$k} =~ /intergenic/;
    print OUTR "mutation_plot_rect($k, $k, \">$k\", $d, col=\"#E69F00\")\n" if $INFO{$k} =~ /upstream/;
    print OUTR "mutation_plot_rect($k, $k, \">$k\", $d, col=\"#0072B2\")\n" if $INFO{$k} =~ /UTR5/;
    print OUTR "mutation_plot_rect($k, $k, \">$k\", $d, col=\"#FF0000\")\n" if $INFO{$k} =~ /exonic/;
    print OUTR "mutation_plot_rect($k, $k, \">$k\", $d, col=\"#009E73\")\n" if $INFO{$k} =~ /intronic/;
    print OUTR "mutation_plot_rect($k, $k, \">$k\", $d, col=\"#56B4E9\")\n" if $INFO{$k} =~ /UTR3/;
    print OUTR "mutation_plot_rect($k, $k, \">$k\", $d, col=\"#CC79A7\")\n" if $INFO{$k} =~ /downstream/;
    $old = $k;
  }
  $w =1;$old=0;
  foreach $k (sort {$a<=>$b} keys %BP ){
    $w++ if ($k < $old + 0.07* ($myend - $mystart));
    $w=1 if ($k > $old + 0.07* ($myend - $mystart));
    $d= $w * (-0.2);
    print OUTR "mutation_plot_text($k, $k, \">$k\", $d, col=\"#303030\")\n" if $INFO{$k} =~ /intergenic/;
    print OUTR "mutation_plot_text($k, $k, \">$k\", $d, col=\"#624300\")\n" if $INFO{$k} =~ /upstream/;
    print OUTR "mutation_plot_text($k, $k, \">$k\", $d, col=\"#00314C\")\n" if $INFO{$k} =~ /UTR5/;
    print OUTR "mutation_plot_text($k, $k, \">$k\", $d, col=\"#6B0000\")\n" if $INFO{$k} =~ /exonic/;
    print OUTR "mutation_plot_text($k, $k, \">$k\", $d, col=\"#004331\")\n" if $INFO{$k} =~ /intronic/;
    print OUTR "mutation_plot_text($k, $k, \">$k\", $d, col=\"#254C62\")\n" if $INFO{$k} =~ /UTR3/;
    print OUTR "mutation_plot_text($k, $k, \">$k\", $d, col=\"#563347\")\n" if $INFO{$k} =~ /downstream/;
    $old = $k;
  }
}
print OUTR "dev.off()\n";
system("Rscript Plot_gene-$opts{g}-$Phenotype.R");
print "Plotted Gene Structure to file Plot_gene-$opts{g}-$Phenotype.pdf\n\n";
print "Plotted Histogram to file Plot_boxplot-$Phenotype-$opts{g}.pdf\n\n\n\n";

system("touch tmp-Diff-$opts{g}.txt");
print "Plotting Boxplot of $opts{g} - $Phenotype ......\n";
open OUTR,">Plot_boxplot-$Phenotype.R" or die $!;
print OUTR <<EOF;
if (! require("ggplot2")) install.packages("ggplot2", repos='https://cran.rstudio.com/')
df<-read.delim("tmp-Boxplot-$Phenotype-$opts{g}.txt",sep="\t",header=F)
names(df)<-c("hap","Phenotype")
if (! require("BiocManager", quietly = TRUE)) install.packages("BiocManager", repos='https://cran.rstudio.com/')
if (! require("agricolae")) BiocManager::install("agricolae")
tmp <- aov(df\$Phenotype ~ df\$hap)
res <- LSD.test(tmp, 'df\$hap', p.adj = 'bonferroni',alpha =0.01)
diff <- res\$groups
write.table(diff, file = "tmp-Diff-$opts{g}.txt", sep = "\t", quote = FALSE, col.names = FALSE)
diff[,'hap']<-factor(rownames(diff))
my_means <-res\$means
my_means[,'hap']<-factor(rownames(my_means))
diff<-merge(diff,my_means,by="hap")
df\$hap<-factor(df\$hap,levels=unique(df\$hap))
if (nrow(diff)-3 > 3) {
    mywidth = (nrow(diff)-3)
} else {mywidth = 4 }
if (! require("ggbeeswarm")) install.packages("ggbeeswarm", repos='https://cran.rstudio.com/')
pdf(file="Plot_boxplot-$Phenotype-$opts{g}.pdf", width=mywidth, height=3)
ggplot(data = df,aes(x = hap, y = Phenotype, group= hap)) + geom_boxplot(fill=rainbow(length(levels(factor(df\$hap)))), outlier.colour = NA, alpha=.1, color=rainbow(length(levels(factor(df\$hap)))))  + geom_beeswarm(size = 0.05, cex = 0.6, alpha=0.5) + labs(title="Boxplot of $opts{g} Gene's Haplotypes", x="Haplotypes", y="Value of Phenotype") + geom_text(data=diff,aes(y=-0.1,label=groups)) + theme(legend.position="none")
ggplot(data = df,aes(x = hap, y = Phenotype, group= hap)) + geom_boxplot(fill=rainbow(length(levels(factor(df\$hap)))), outlier.colour = NA, alpha=.1, color=rainbow(length(levels(factor(df\$hap)))))  +  geom_point(size=0.1,position = position_jitter(width=0.15, height = 0), alpha=.5,shape=20) +labs(title="Boxplot of $opts{g} Gene's Haplotypes", x="Haplotypes", y="Value of Phenotype") + geom_text(data=diff,aes(y=-0.1,label=groups))
ggplot(data = df,aes(x = hap, y = Phenotype, group= hap)) + geom_boxplot(fill=rainbow(length(levels(factor(df\$hap)))), outlier.colour = NA) +  geom_point(size=0.1,position = position_jitter(width=0.15, height = 0), alpha=.5,shape=20) +labs(title="Boxplot of $opts{g} Gene's Haplotypes", x="Haplotypes", y="Value of Phenotype") + geom_text(data=diff,aes(y=-0.1,label=r))
#boxplot(Phenotype~hap,data=df, col=rainbow(length(levels(factor(df\$hap)))), xlab = "Haplotypes", ylab = "Value of Phenotype", main = "Boxplot of $opts{g} Gene's Haplotypes")
dev.off()
EOF
system("Rscript Plot_boxplot-$Phenotype.R");
print "Plotted Boxplot to file Plot_boxplot-$Phenotype-$opts{g}.pdf\n\n\n\n";

if ($opts{n}) {
print "Plotting Haplotype Network of $opts{g} ......\n";
open OUTR,">Plot_Network-$opts{g}.R" or die $!;
print OUTR <<EOF;
if (! require("sf")) install.packages('sf', repos='https://cran.rstudio.com/')
if (! require("pegas")) install.packages('pegas', repos='https://cran.rstudio.com/')
fa <- read.FASTA("tmp-seq-$opts{g}.txt")
haps <- haplotype(fa)
(network <- haploNet(haps))
ind.hap<-with(
    stack(setNames(attr(haps, "index"), rownames(haps))), 
    table(hap=ind, pop=labels(fa)[values])
)
ind.hap
pdf(file="Plot-haploNet-$opts{g}.pdf")
plot(network, size = log2(attr(network, "freq")), scale.ratio = 2, cex = 0.8, show.mutation=1, pie=ind.hap, bg=adjustcolor(rainbow(ncol(ind.hap)), alpha=0.5), fast = TRUE, labels = F)
legend("topleft", colnames(ind.hap), col=adjustcolor(rainbow(ncol(ind.hap)), alpha=0.5), pch=20, pt.cex=3)
dev.off()
as.data.frame(diffHaplo(haps,1:nrow(haps)))
EOF
system("Rscript Plot_Network-$opts{g}.R");
print "Plotted Haplotype Network to file Plot-haploNet-$opts{g}.pdf\n\n\n";
}

open DIFF,"tmp-Diff-$opts{g}.txt" or die $!;
while (<DIFF>) {
    $_ =~ s/\n*|\r*//g;
    @D = split(/\t/,$_);
    $diff{$D[0]}=$D[2];
}
if ($stop) {
    open HAP,">Hap_result-$opts{g}-$Phenotype-$stop.txt" or die $!;
    print "Print Haplotypes results to file: Hap_result-$opts{g}-$Phenotype-$stop.txt\n\n";
} else {
    open HAP,">Hap_result-$opts{g}-$Phenotype.txt" or die $!;
    print "Print Haplotypes results to file: Hap_result-$opts{g}-$Phenotype.txt\n\n";
}
open HAP1,"tmp-Hap-$opts{g}-$Phenotype.txt" or die $!;
while (<HAP1>) {
    $_ =~ s/\s+$//g;
    ($head,$info) = split(/\t/,$_,2);
    print HAP "$head\t$info\t$diff{$head}\n";
}
if  ($opts{k} == 0) {
    system("rm -rf tmp*");
    system("rm -rf *.R");
}
system("rm -rf Rplots.pdf");
my $duration_time=time-$start_time;
print strftime("End time is %Y-%m-%d %H:%M:%S\n", localtime(time));
print "This compute totally consumed $duration_time s\.\n";
system("mkdir Result-$opts{g}-$Phenotype");
system("mv Hap* ./Result-$opts{g}-$Phenotype");
system("mv Plot* ./Result-$opts{g}-$Phenotype");
system("mv Line* ./Result-$opts{g}-$Phenotype");
system("mv tmp* ./Result-$opts{g}-$Phenotype");
system("mv *.R ./Result-$opts{g}-$Phenotype");
exit(1);